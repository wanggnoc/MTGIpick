unzip MCRInstaller.zip -d MCRInstaller
cd MCRInstaller
./install -mode silent -agreeToLicense yes
